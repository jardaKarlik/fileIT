// src-tauri/src/commands/mod.rs
//
// Tauri IPC command handlers.
// Every function here is callable from the React frontend via:
//   invoke('command_name', { ...args })
//
// All commands are async. Heavy work is spawned onto Tokio task pool.
// SessionState is held in a Tauri-managed Mutex.

use crate::backup;
use crate::classifier::Classifier;
use crate::scanner;
use crate::restructure;
use crate::types::*;
use anyhow::Result;
use chrono::Utc;
use std::path::PathBuf;
use std::sync::Mutex;
use tauri::{AppHandle, Manager, State};

/// Global session state — wrapped in Mutex for thread-safe access.
pub struct AppState {
    pub session: Mutex<SessionState>,
    pub classifier: Classifier,
    pub app_data_dir: PathBuf,
}

// ─────────────────────────────────────────────────────────────────────────────
// Setup & app lifecycle
// ─────────────────────────────────────────────────────────────────────────────

/// Called on app start. Returns any pending confirmation from a previous run.
#[tauri::command]
pub async fn app_init(
    state: State<'_, AppState>,
) -> Result<Option<CompletedRun>, String> {
    let run = backup::load_completed_run(&state.app_data_dir);

    // Check if auto-confirm deadline has passed
    if let Some(ref r) = run {
        if Utc::now() > r.auto_confirm_at
            && r.confirmation_status == ConfirmationStatus::Pending
        {
            let mut mut_run = r.clone();
            mut_run.confirmation_status = ConfirmationStatus::AutoConfirmed;
            let _ = backup::save_completed_run(&mut_run, &state.app_data_dir);
            // Schedule ZIP cleanup
            let _ = backup::cleanup_expired_backups(&state.app_data_dir);
            return Ok(None);
        }
    }

    Ok(run)
}

/// Detect installed cloud sync clients.
#[tauri::command]
pub async fn detect_clouds() -> Vec<DetectedCloud> {
    scanner::detect_cloud_clients()
}

// ─────────────────────────────────────────────────────────────────────────────
// Scanning
// ─────────────────────────────────────────────────────────────────────────────

/// Start a scan. Emits "scan_progress" events as it runs.
/// When done, returns a ScanResult.
#[tauri::command]
pub async fn start_scan(
    app: AppHandle,
    state: State<'_, AppState>,
    request: ScanRequest,
) -> Result<ScanResult, String> {
    // Parse categories
    let categories: Vec<FileCategory> = request
        .file_categories
        .iter()
        .filter_map(|s| match s.as_str() {
            "pdf" => Some(FileCategory::Pdf),
            "word" => Some(FileCategory::Word),
            "excel" => Some(FileCategory::Excel),
            "image" => Some(FileCategory::Image),
            "email" => Some(FileCategory::Email),
            "text" => Some(FileCategory::Text),
            _ => None,
        })
        .collect();

    // Reset session state for new scan
    {
        let mut session = state.session.lock().map_err(|e| e.to_string())?;
        *session = SessionState::new();
        session.scan_roots = request.roots.clone();
        session.file_categories = categories.clone();
    }

    // Scan filesystem
    let records = scanner::scan_directories(&app, request.roots, &categories, &[])
        .await
        .map_err(|e| e.to_string())?;

    // Classify all files
    let mut classified: Vec<ClassifiedFile> = Vec::new();
    let total = records.len();

    // Mark duplicates while classifying
    let mut seen_hashes = std::collections::HashMap::new();

    for (i, record) in records.into_iter().enumerate() {
        let sha = record.sha256.clone();
        let mut cf = state.classifier.classify(record).await;

        // Dedup marking
        if let Some(ref hash) = sha {
            if let Some(first_path) = seen_hashes.get(hash) {
                cf.is_duplicate = true;
                cf.duplicate_of = Some(first_path.clone());
            } else {
                seen_hashes.insert(hash.clone(), cf.record.path.clone());
            }
        }

        // Emit classification progress every 5 files
        if i % 5 == 0 {
            let _ = app.emit(
                "classify_progress",
                serde_json::json!({
                    "done": i,
                    "total": total,
                    "current": cf.record.name
                }),
            );
        }

        classified.push(cf);
    }

    // Aggregate stats
    let customers_found = classified.iter()
        .filter_map(|f| f.customer.as_ref())
        .map(|c| c.name.clone())
        .collect::<std::collections::HashSet<_>>()
        .len();

    let duplicates_found = classified.iter().filter(|f| f.is_duplicate).count();
    let total_size: u64 = classified.iter().map(|f| f.record.size_bytes).sum();

    let result = ScanResult {
        total_files: classified.len(),
        total_size_bytes: total_size,
        customers_found,
        duplicates_found,
        files: classified.clone(),
    };

    // Store in session
    {
        let mut session = state.session.lock().map_err(|e| e.to_string())?;
        session.classified_files = classified;
    }

    Ok(result)
}

// ─────────────────────────────────────────────────────────────────────────────
// Restructure
// ─────────────────────────────────────────────────────────────────────────────

/// Build a restructure preview. No filesystem changes.
#[tauri::command]
pub async fn build_preview(
    state: State<'_, AppState>,
    request: PreviewRequest,
) -> Result<RestructurePreview, String> {
    let structure: Vec<GroupDimension> = request
        .structure
        .iter()
        .filter_map(|s| match s.as_str() {
            "customer" => Some(GroupDimension::Customer),
            "date" => Some(GroupDimension::Date),
            "inst" => Some(GroupDimension::Institution),
            "doc" => Some(GroupDimension::DocumentType),
            _ => None,
        })
        .collect();

    let session = state.session.lock().map_err(|e| e.to_string())?;

    if session.classified_files.is_empty() {
        return Err("No classified files in session. Run a scan first.".to_string());
    }

    let preview = restructure::preview(
        &session.classified_files,
        &structure,
        &request.target_path,
    )
    .map_err(|e| e.to_string())?;

    Ok(preview)
}

/// Execute the restructure. Emits "restructure_progress" events.
#[tauri::command]
pub async fn run_restructure(
    app: AppHandle,
    state: State<'_, AppState>,
    request: RunRestructureRequest,
) -> Result<RestructureResult, String> {
    let (planned_moves, session_id, classified_files) = {
        let session = state.session.lock().map_err(|e| e.to_string())?;
        let preview = session.preview.as_ref()
            .ok_or("No preview computed. Call build_preview first.")?;
        (
            preview.planned_moves.clone(),
            session.id.clone(),
            session.classified_files.clone(),
        )
    };

    // Create backup if enabled
    let backup_zip_path = if request.backup_enabled {
        // Build a partial manifest (will be completed after moves finish)
        let temp_manifest = BackupManifest::new(&session_id, vec![]);
        match backup::create_backup(&classified_files, &temp_manifest, &state.app_data_dir) {
            Ok(path) => Some(path),
            Err(e) => {
                log::warn!("Backup creation failed (continuing without): {}", e);
                None
            }
        }
    } else {
        None
    };

    // Execute moves
    let (manifest_entries, folders_created, duration_secs) =
        restructure::execute(&app, &planned_moves, &session_id)
            .await
            .map_err(|e| e.to_string())?;

    let files_moved = manifest_entries.len();
    let unknown_count = planned_moves
        .iter()
        .filter(|m| {
            m.destination
                .to_string_lossy()
                .contains("Neznámý klient")
        })
        .count();

    // Build final manifest
    let manifest = BackupManifest::new(&session_id, manifest_entries);

    // Persist manifest sidecar for restore functionality
    let _ = backup::save_manifest_sidecar(&manifest, &state.app_data_dir);

    // Build and persist CompletedRun
    let completed_run = {
        let session = state.session.lock().map_err(|e| e.to_string())?;
        let target = session.preview
            .as_ref()
            .map(|p| p.target_path.clone())
            .unwrap_or_default();

        CompletedRun {
            session_id: session_id.clone(),
            completed_at: Utc::now(),
            duration_seconds: duration_secs,
            files_moved,
            folders_created,
            unknown_count,
            target_path: target,
            backup_zip_path: backup_zip_path.clone().unwrap_or_default(),
            manifest,
            confirmation_status: ConfirmationStatus::Pending,
            auto_confirm_at: Utc::now() + chrono::Duration::days(30),
            backup_delete_at: None,
        }
    };

    let _ = backup::save_completed_run(&completed_run, &state.app_data_dir);

    Ok(RestructureResult {
        session_id,
        files_moved,
        folders_created,
        unknown_count,
        duration_seconds: duration_secs,
        backup_zip_path: backup_zip_path.map(|p| p.to_string_lossy().to_string()),
    })
}

// ─────────────────────────────────────────────────────────────────────────────
// Confirmation / Restore
// ─────────────────────────────────────────────────────────────────────────────

/// User confirms the restructure result. Schedules backup deletion.
#[tauri::command]
pub async fn confirm_restructure(
    state: State<'_, AppState>,
) -> Result<(), String> {
    let mut run = backup::load_completed_run(&state.app_data_dir)
        .ok_or("No completed run found")?;

    run.confirmation_status = ConfirmationStatus::Confirmed;
    // ZIP deletes 7 days from now
    run.backup_delete_at = Some(Utc::now() + chrono::Duration::days(7));

    backup::save_completed_run(&run, &state.app_data_dir)
        .map_err(|e| e.to_string())?;

    backup::delete_manifest_sidecar(&state.app_data_dir)
        .map_err(|e| e.to_string())?;

    Ok(())
}

/// User triggers restore. Moves all files back to original locations.
#[tauri::command]
pub async fn restore_restructure(
    app: AppHandle,
    state: State<'_, AppState>,
) -> Result<usize, String> {
    let run = backup::load_completed_run(&state.app_data_dir)
        .ok_or("No completed run found")?;

    let restored = restructure::restore(&app, &run.manifest)
        .await
        .map_err(|e| e.to_string())?;

    // Delete the backup ZIP — restore succeeded, it's no longer needed
    if run.backup_zip_path.as_os_str().len() > 0 {
        let _ = backup::delete_backup_zip(&run.backup_zip_path);
    }
    let _ = backup::delete_completed_run(&state.app_data_dir);
    let _ = backup::delete_manifest_sidecar(&state.app_data_dir);

    Ok(restored)
}

// ─────────────────────────────────────────────────────────────────────────────
// Utility commands
// ─────────────────────────────────────────────────────────────────────────────

/// Open a native folder-picker dialog. Returns the chosen path or None.
#[tauri::command]
pub async fn pick_folder(app: AppHandle) -> Option<String> {
    use tauri_plugin_dialog::DialogExt;
    app.dialog()
        .file()
        .pick_folder()
        .blocking_pick_folder()
        .map(|p| p.to_string_lossy().to_string())
}

/// Open a path in the OS file explorer (Windows Explorer).
#[tauri::command]
pub async fn open_in_explorer(path: String) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        std::process::Command::new("explorer")
            .arg(&path)
            .spawn()
            .map_err(|e| e.to_string())?;
    }
    Ok(())
}
