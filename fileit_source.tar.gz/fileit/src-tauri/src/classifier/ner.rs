// src-tauri/src/classifier/ner.rs
//
// Czech Named Entity Recognition for FileIT.
// Uses regex patterns for structured identifiers (rodné číslo, IČO)
// and keyword dictionaries for institutions and document types.

use crate::types::*;
use anyhow::Result;
use chrono::{DateTime, NaiveDate, TimeZone, Utc};
use once_cell::sync::OnceCell;
use regex::Regex;
use serde::Deserialize;
use std::collections::HashMap;

// ─────────────────────────────────────────────────────────────────────────────
// Dictionary structures (mirrors institution_dictionary.json)
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Debug, Deserialize)]
struct DictionaryJson {
    institutions: Vec<InstitutionEntry>,
    document_type_triggers: HashMap<String, Vec<String>>,
    rodne_cislo_pattern: String,
    ico_pattern: String,
    dic_pattern: String,
}

#[derive(Debug, Deserialize)]
struct InstitutionEntry {
    canonical_name: String,
    category: String,
    keywords: Vec<String>,
    weight: f32,
}

// ─────────────────────────────────────────────────────────────────────────────
// Compiled NER engine
// ─────────────────────────────────────────────────────────────────────────────

pub struct NerEngine {
    rodne_cislo_re: Regex,
    ico_re: Regex,
    dic_re: Regex,
    date_re: Regex,
    name_re: Regex,
    institutions: Vec<CompiledInstitution>,
    doc_type_triggers: Vec<(DocumentType, Vec<String>)>,
}

struct CompiledInstitution {
    canonical_name: String,
    category: InstitutionCategory,
    keywords: Vec<String>,
    weight: f32,
}

impl NerEngine {
    pub fn from_json(json: &str) -> Result<Self> {
        let dict: DictionaryJson = serde_json::from_str(json)
            .map_err(|e| anyhow::anyhow!("Failed to parse dictionary: {}", e))?;

        let rodne_cislo_re = Regex::new(&dict.rodne_cislo_pattern)?;
        let ico_re = Regex::new(&dict.ico_pattern)?;
        let dic_re = Regex::new(&dict.dic_pattern)?;

        // Czech date patterns: dd.mm.yyyy, dd. mm. yyyy, dd/mm/yyyy
        let date_re = Regex::new(
            r"(?:^|\s)(\d{1,2})[.\s/](\d{1,2})[.\s/](20\d{2})(?:\s|$)"
        )?;

        // Czech name pattern: Capitalized Surname, Title? Firstname? (very loose)
        // Looks for patterns like "Novák Pavel" or "Horáková Jana" near identifiers
        let name_re = Regex::new(
            r"\b([A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-záčďéěíňóřšťúůýž]{2,})\s+([A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-záčďéěíňóřšťúůýž]{2,})\b"
        )?;

        let institutions = dict.institutions.into_iter().map(|e| {
            let category = match e.category.as_str() {
                "bank" => InstitutionCategory::Bank,
                "insurance" => InstitutionCategory::Insurance,
                "government" => InstitutionCategory::Government,
                "utility" => InstitutionCategory::Utility,
                "telco" => InstitutionCategory::Telco,
                "legal" => InstitutionCategory::Legal,
                _ => InstitutionCategory::Other,
            };
            CompiledInstitution {
                canonical_name: e.canonical_name,
                category,
                keywords: e.keywords,
                weight: e.weight,
            }
        }).collect();

        let doc_type_triggers = dict.document_type_triggers.into_iter()
            .filter_map(|(k, v)| {
                let dt = match k.as_str() {
                    "Contract" => DocumentType::Contract,
                    "BankStatement" => DocumentType::BankStatement,
                    "BankLetter" => DocumentType::BankLetter,
                    "Invoice" => DocumentType::Invoice,
                    "PaymentDemand" => DocumentType::PaymentDemand,
                    "TaxReturn" => DocumentType::TaxReturn,
                    "UtilityBill" => DocumentType::UtilityBill,
                    "InsuranceContract" => DocumentType::InsuranceContract,
                    "AdminDecision" => DocumentType::AdminDecision,
                    "Identity" => DocumentType::Identity,
                    "LegalLetter" => DocumentType::LegalLetter,
                    _ => return None,
                };
                Some((dt, v))
            })
            .collect();

        Ok(Self {
            rodne_cislo_re,
            ico_re,
            dic_re,
            date_re,
            name_re,
            institutions,
            doc_type_triggers,
        })
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Customer extraction
    // ─────────────────────────────────────────────────────────────────────────

    /// Find all customer references in the text.
    /// Uses rodné číslo as primary anchor; then searches for adjacent names.
    pub fn find_customers(&self, text: &str) -> Vec<CustomerMatch> {
        let mut customers: Vec<CustomerMatch> = Vec::new();

        // Primary path: find rodné číslo then look for nearby names
        for rc_match in self.rodne_cislo_re.find_iter(text) {
            let rc = rc_match.as_str().replace("/", "").replace(" ", "");
            if !self.is_valid_rodne_cislo(&rc) {
                continue;
            }

            // Look for a name in a 200-char window around the rodné číslo
            let start = rc_match.start().saturating_sub(200);
            let end = (rc_match.end() + 200).min(text.len());
            let window = &text[start..end];
            let name = self.name_re.find(window)
                .map(|m| m.as_str().to_string());

            customers.push(CustomerMatch {
                name: name.unwrap_or_else(|| format!("Klient (r.č. {})", &rc[..6])),
                rodne_cislo: Some(rc),
                ico: None,
                confidence: 0.92,
            });
        }

        // Secondary path: find IČO (business customers)
        for ico_match in self.ico_re.captures_iter(text) {
            let ico = ico_match.get(2).map(|m| m.as_str().to_string());
            if let Some(ref ico_val) = ico {
                // Don't duplicate if already found via rodné číslo
                if customers.iter().any(|c| c.ico.as_deref() == Some(ico_val)) {
                    continue;
                }
                let window_start = ico_match.get(0).map(|m| m.start().saturating_sub(200)).unwrap_or(0);
                let window_end = ico_match.get(0).map(|m| (m.end() + 200).min(text.len())).unwrap_or(text.len());
                let window = &text[window_start..window_end];
                let name = self.name_re.find(window)
                    .map(|m| m.as_str().to_string())
                    .unwrap_or_else(|| format!("Firma (IČO {})", ico_val));

                customers.push(CustomerMatch {
                    name,
                    rodne_cislo: None,
                    ico,
                    confidence: 0.85,
                });
            }
        }

        // Deduplicate by rodné číslo / IČO
        customers.dedup_by(|a, b| {
            a.rodne_cislo == b.rodne_cislo && a.rodne_cislo.is_some()
        });

        customers
    }

    /// Validate Czech rodné číslo format and checksum (post-1954 numbers).
    fn is_valid_rodne_cislo(&self, rc: &str) -> bool {
        let digits: String = rc.chars().filter(|c| c.is_ascii_digit()).collect();
        if digits.len() != 9 && digits.len() != 10 {
            return false;
        }

        let yy: u32 = digits[..2].parse().unwrap_or(0);
        let mm: u32 = digits[2..4].parse().unwrap_or(0);
        let dd: u32 = digits[4..6].parse().unwrap_or(0);

        // Month: 1-12 (male) or 51-62 (female)
        let mm_norm = if mm > 50 { mm - 50 } else { mm };
        if mm_norm < 1 || mm_norm > 12 { return false; }
        if dd < 1 || dd > 31 { return false; }

        // 10-digit numbers (post-1953) must be divisible by 11
        if digits.len() == 10 {
            let n: u64 = digits.parse().unwrap_or(1);
            if n % 11 != 0 { return false; }
        }

        true
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Institution matching
    // ─────────────────────────────────────────────────────────────────────────

    pub fn find_institution(&self, text_lower: &str) -> Option<InstitutionMatch> {
        let mut best: Option<(&CompiledInstitution, f32)> = None;

        for inst in &self.institutions {
            let mut hit_count = 0usize;
            for kw in &inst.keywords {
                if text_lower.contains(kw.as_str()) {
                    hit_count += 1;
                }
            }
            if hit_count == 0 {
                continue;
            }

            // Confidence: proportion of keywords hit × institution weight
            let raw_conf = (hit_count as f32 / inst.keywords.len() as f32) * inst.weight;
            let conf = raw_conf.min(0.98);

            if best.is_none() || conf > best.as_ref().unwrap().1 {
                best = Some((inst, conf));
            }
        }

        best.map(|(inst, conf)| InstitutionMatch {
            canonical_name: inst.canonical_name.clone(),
            category: inst.category.clone(),
            confidence: conf,
        })
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Document type matching
    // ─────────────────────────────────────────────────────────────────────────

    pub fn find_document_type(&self, text_lower: &str) -> DocumentType {
        let mut best_type = DocumentType::Unknown;
        let mut best_score = 0usize;

        for (dt, triggers) in &self.doc_type_triggers {
            let hits = triggers.iter()
                .filter(|t| text_lower.contains(t.as_str()))
                .count();
            if hits > best_score {
                best_score = hits;
                best_type = dt.clone();
            }
        }

        best_type
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Date extraction
    // ─────────────────────────────────────────────────────────────────────────

    pub fn find_date(&self, text: &str) -> Option<DateTime<Utc>> {
        for cap in self.date_re.captures_iter(text) {
            let day: u32 = cap[1].parse().ok()?;
            let month: u32 = cap[2].parse().ok()?;
            let year: i32 = cap[3].parse().ok()?;

            if let Some(date) = NaiveDate::from_ymd_opt(year, month, day) {
                return Some(Utc.from_utc_datetime(&date.and_hms_opt(0, 0, 0)?));
            }
        }
        None
    }
}
