// src-tauri/src/classifier/mod.rs
//
// FileIT classifier — reads file content and extracts:
//   • Customer identity (rodné číslo, IČO, name)
//   • Issuing institution (from keyword dictionary)
//   • Document type (from trigger phrase matching)
//   • Document date
//   • Overall confidence score

mod extractor;
mod ner;
mod scorer;

pub use extractor::extract_text;
pub use ner::NerEngine;
pub use scorer::score_classification;

use crate::types::*;
use anyhow::Result;
use log::{debug, warn};
use std::path::Path;

/// The top-level classifier. Instantiated once, shared across the session.
pub struct Classifier {
    pub ner: NerEngine,
}

impl Classifier {
    /// Load from the bundled institution dictionary.
    pub fn new(dictionary_json: &str) -> Result<Self> {
        let ner = NerEngine::from_json(dictionary_json)?;
        Ok(Self { ner })
    }

    /// Classify a single FileRecord, returning a ClassifiedFile.
    /// Text extraction happens here; caller is responsible for tokio context.
    pub async fn classify(&self, record: FileRecord) -> ClassifiedFile {
        let ext = record.extension.as_str();
        let category = FileCategory::from_extension(ext);

        // Extract text content
        let (raw_text, ocr_used) = match extract_text(&record.path, &category).await {
            Ok(result) => result,
            Err(e) => {
                warn!("Text extraction failed for {:?}: {}", record.path, e);
                (String::new(), false)
            }
        };

        let text_lower = raw_text.to_lowercase();

        // NER pass
        let customers = self.ner.find_customers(&raw_text);
        let institution = self.ner.find_institution(&text_lower);
        let document_type = self.ner.find_document_type(&text_lower);
        let document_date = self.ner.find_date(&raw_text);

        let primary_customer = customers.first().cloned();
        let confidence = score_classification(
            &primary_customer,
            &institution,
            &document_type,
            ocr_used,
            raw_text.len(),
        );

        let text_preview = if raw_text.is_empty() {
            None
        } else {
            Some(raw_text.chars().take(500).collect())
        };

        debug!(
            "Classified {:?}: customer={:?}, inst={:?}, type={:?}, conf={:.2}",
            record.name,
            primary_customer.as_ref().map(|c| &c.name),
            institution.as_ref().map(|i| &i.canonical_name),
            document_type,
            confidence
        );

        ClassifiedFile {
            record,
            category,
            customer: primary_customer,
            all_customers: customers,
            institution,
            document_type,
            document_date,
            confidence,
            ocr_used,
            text_preview,
            is_duplicate: false,
            duplicate_of: None,
        }
    }
}
