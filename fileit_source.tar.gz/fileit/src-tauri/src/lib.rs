// src-tauri/src/lib.rs
//
// FileIT Tauri application library entry point.
// Initialises all plugins, loads resources, registers IPC commands,
// and manages the AppState.

mod backup;
mod classifier;
mod commands;
mod restructure;
mod scanner;
mod types;

use commands::AppState;
use std::sync::Mutex;

pub fn run() {
    // Load the institution dictionary — bundled as a resource
    let dictionary_json = include_str!("../resources/institution_dictionary.json");

    let classifier = classifier::Classifier::new(dictionary_json)
        .expect("Failed to initialise classifier — check institution_dictionary.json");

    tauri::Builder::default()
        // ── Plugins ──────────────────────────────────────────────────────────
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_shell::init())
        .plugin(
            tauri_plugin_log::Builder::default()
                .level(log::LevelFilter::Info)
                .build(),
        )
        // ── App state ─────────────────────────────────────────────────────────
        .setup(|app| {
            let app_data_dir = app
                .path()
                .app_data_dir()
                .expect("Could not resolve AppData directory");

            std::fs::create_dir_all(&app_data_dir)
                .expect("Could not create AppData directory");

            // Run startup cleanup (expired backups, auto-confirm checks)
            let _ = backup::cleanup_expired_backups(&app_data_dir);

            app.manage(AppState {
                session: Mutex::new(types::SessionState::new()),
                classifier,
                app_data_dir,
            });

            Ok(())
        })
        // ── IPC commands ──────────────────────────────────────────────────────
        .invoke_handler(tauri::generate_handler![
            commands::app_init,
            commands::detect_clouds,
            commands::start_scan,
            commands::build_preview,
            commands::run_restructure,
            commands::confirm_restructure,
            commands::restore_restructure,
            commands::pick_folder,
            commands::open_in_explorer,
        ])
        .run(tauri::generate_context!())
        .expect("Error running FileIT application");
}
