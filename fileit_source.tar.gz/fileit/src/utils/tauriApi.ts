// src/utils/tauriApi.ts
// Thin wrappers around Tauri invoke() calls.
// When running in a browser (dev without Tauri), falls back to mock data
// so the UI can be developed and iterated without a compiled backend.

import {
  CompletedRun, DetectedCloud, RestructurePreview,
  RestructureResult, ScanResult,
} from '../types';

// Detect whether we are inside a Tauri window
const IS_TAURI = typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;

async function invoke<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  if (IS_TAURI) {
    const { invoke: tauriInvoke } = await import('@tauri-apps/api/core');
    return tauriInvoke<T>(cmd, args);
  }
  // Dev mock — returns plausible data so the UI renders without a backend
  return devMock(cmd, args) as T;
}

async function listen(event: string, cb: (payload: unknown) => void): Promise<() => void> {
  if (IS_TAURI) {
    const { listen: tauriListen } = await import('@tauri-apps/api/event');
    const unlisten = await tauriListen(event, (e) => cb(e.payload));
    return unlisten;
  }
  // No-op in dev
  return () => {};
}

// ─────────────────────────────────────────────────────────────────────────────
// API surface
// ─────────────────────────────────────────────────────────────────────────────

export const api = {
  /** Called on app start. Returns pending CompletedRun if one exists. */
  appInit: () => invoke<CompletedRun | null>('app_init'),

  /** Detect installed cloud sync clients. */
  detectClouds: () => invoke<DetectedCloud[]>('detect_clouds'),

  /** Open native folder picker. Returns chosen path or null. */
  pickFolder: () => invoke<string | null>('pick_folder'),

  /** Open a path in Windows Explorer. */
  openInExplorer: (path: string) => invoke<void>('open_in_explorer', { path }),

  /** Start a scan. Progress events come via onScanProgress listener. */
  startScan: (roots: string[], fileCategories: string[]) =>
    invoke<ScanResult>('start_scan', { request: { roots, file_categories: fileCategories } }),

  /** Build a restructure preview without moving files. */
  buildPreview: (structure: string[], targetPath: string, destinationMode: string) =>
    invoke<RestructurePreview>('build_preview', {
      request: { structure, target_path: targetPath, destination_mode: destinationMode },
    }),

  /** Execute the restructure. Progress events come via onRestructureProgress. */
  runRestructure: (backupEnabled: boolean) =>
    invoke<RestructureResult>('run_restructure', { request: { backup_enabled: backupEnabled } }),

  /** Confirm the restructure result. */
  confirmRestructure: () => invoke<void>('confirm_restructure'),

  /** Restore all files to original locations. */
  restoreRestructure: () => invoke<number>('restore_restructure'),

  // ── Event listeners ───────────────────────────────────────────────────────

  onScanProgress: (cb: (p: { files_found: number; message: string; done: boolean }) => void) =>
    listen('scan_progress', cb as any),

  onClassifyProgress: (cb: (p: { done: number; total: number; current: string }) => void) =>
    listen('classify_progress', cb as any),

  onRestructureProgress: (cb: (p: {
    files_moved: number; total_files: number;
    current_file: string; log_line: string; done: boolean; error: string | null;
  }) => void) => listen('restructure_progress', cb as any),

  onRestoreProgress: (cb: (p: {
    restored: number; total: number; log_line: string; done: boolean;
  }) => void) => listen('restore_progress', cb as any),
};

// ─────────────────────────────────────────────────────────────────────────────
// Dev mocks — used when running in browser without Tauri
// ─────────────────────────────────────────────────────────────────────────────

function devMock(cmd: string, _args?: Record<string, unknown>): unknown {
  switch (cmd) {
    case 'app_init':
      return null;

    case 'detect_clouds':
      return [
        { name: 'OneDrive', root_path: 'C:\\Users\\Anna\\OneDrive', is_running: true },
        { name: 'Dropbox', root_path: 'C:\\Users\\Anna\\Dropbox', is_running: false },
      ] satisfies DetectedCloud[];

    case 'pick_folder':
      return 'C:\\Klienti\\2026\\';

    case 'open_in_explorer':
      console.log('[dev] open_in_explorer called');
      return undefined;

    case 'start_scan':
      return {
        total_files: 284,
        total_size_bytes: 2_576_351_232,
        customers_found: 38,
        duplicates_found: 24,
        files: [],
      } satisfies ScanResult;

    case 'build_preview':
      return {
        total_files: 284,
        total_folders: 38,
        total_subfolders: 127,
        unknown_count: 11,
        duplicate_count: 24,
        target_path: 'C:\\FileIT\\Organized\\',
        planned_moves: [],
        target_has_existing_files: false,
        existing_file_count: 0,
      } satisfies RestructurePreview;

    case 'run_restructure':
      return {
        session_id: 'dev-session-001',
        files_moved: 273,
        folders_created: 165,
        unknown_count: 11,
        duration_seconds: 252,
        backup_zip_path: 'C:\\AppData\\FileIT\\backups\\backup_2026-04-17_143300.zip',
      } satisfies RestructureResult;

    case 'confirm_restructure':
    case 'restore_restructure':
      return undefined;

    default:
      console.warn('[dev] Unhandled mock command:', cmd);
      return null;
  }
}
