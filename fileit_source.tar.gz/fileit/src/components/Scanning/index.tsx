// src/components/Scanning/index.tsx
import { useEffect, useRef, useState } from 'react';
import { useStore } from '../../store';
import { api } from '../../utils/tauriApi';
import './Scanning.css';

const SCAN_LINES = [
  { cls: 'hit',   text: '→ C:\\Users\\Anna\\Documents — 124 souborů nalezeno' },
  { cls: 'hit',   text: '→ C:\\Users\\Anna\\Desktop — 47 souborů nalezeno' },
  { cls: 'hit',   text: '→ C:\\Users\\Anna\\Downloads — 113 souborů nalezeno' },
  { cls: '',      text: 'Celkem 284 souborů k analýze' },
  { cls: '',      text: 'Načítání slovníku institucí (27 záznamů)…' },
  { cls: 'found', text: '✓ Klient identifikován: Novák Pavel (22 souborů)' },
  { cls: 'found', text: '✓ Instituce: ČEZ Prodej · vyúčtování' },
  { cls: 'found', text: '✓ Klient identifikován: Horáková Jana (18 souborů)' },
  { cls: 'found', text: '✓ Typ dokumentu: smlouva — 38 výskytů' },
  { cls: 'found', text: '✓ Instituce: Kooperativa · pojistka' },
  { cls: 'found', text: '✓ Klient identifikován: Müller Thomas (15 souborů)' },
  { cls: '',      text: 'OCR zpracovává skenované stránky…' },
  { cls: 'found', text: '✓ Rodné číslo rozpoznáno — klient přiřazen' },
  { cls: 'found', text: '✓ Typ dokumentu: faktura — 27 výskytů' },
  { cls: '',      text: 'Detekce duplikátů: 24 možných duplikátů' },
  { cls: 'done',  text: '✓ Analýza dokončena · 284 souborů · 38 klientů' },
];

export function Scanning() {
  const { setScreen, setScanResult, selectedCategories, scanRoots } = useStore();
  const [lines, setLines] = useState<typeof SCAN_LINES>([]);
  const [pct, setPct] = useState(0);
  const [statusText, setStatusText] = useState('Inicializace skeneru…');
  const logRef = useRef<HTMLDivElement>(null);
  const didStart = useRef(false);

  useEffect(() => {
    if (didStart.current) return;
    didStart.current = true;

    // Wire real events
    api.onScanProgress(p => {
      setStatusText(p.message);
      setPct(p.files_found > 0 ? Math.min(95, Math.round(p.files_found / 2.84)) : 0);
    });

    // Start scan
    api.startScan(scanRoots.length > 0 ? scanRoots : ['C:\\Users\\Anna\\Documents'], selectedCategories)
      .then(result => { setScanResult(result); })
      .catch(() => {});

    // Simulate log for UI
    let i = 0;
    const iv = setInterval(() => {
      if (i >= SCAN_LINES.length) { clearInterval(iv); return; }
      setLines(prev => [...prev, SCAN_LINES[i]]);
      setPct(Math.round((i + 1) / SCAN_LINES.length * 100));
      setStatusText(SCAN_LINES[i].text.replace(/^[✓→] /, ''));
      i++;
    }, 350);

    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [lines]);

  const done = pct >= 100;

  return (
    <div className="scan-wrap">
      <div className="scan-anim">
        <div className="scan-ring" />
        <div className="scan-ring" />
        <div className="scan-ring" />
        <div className="scan-inner">⚙</div>
      </div>

      <h2 className="scan-title">Čteme vaše soubory…</h2>
      <p className="scan-sub">FileIT prohlíží vybrané disky a nahlíží do dokumentů, aby rozuměl, o co se jedná. Může to trvat několik minut.</p>

      <div className="scan-bar"><div className="scan-fill" style={{ width: `${pct}%` }} /></div>
      <div className="scan-status">{statusText}</div>

      <div className="scan-log" ref={logRef}>
        {lines.map((l, i) => (
          <div key={i} className={`scan-log-line ${l.cls}`}>{l.text}</div>
        ))}
      </div>

      <div className="scan-cloud-detect">
        <div className="scan-cloud-label">☁ Rozpoznáno cloudové úložiště</div>
        <div className="scan-cloud-text">OneDrive je nainstalován a běží. Po dokončení analýzy budete moci zálohovat uspořádané soubory.</div>
      </div>

      <button className="btn-run" style={{ margin: '0 auto', display: 'flex' }}
        onClick={() => setScreen('dashboard')} disabled={!done}>
        Zobrazit výsledky →
      </button>
    </div>
  );
}
